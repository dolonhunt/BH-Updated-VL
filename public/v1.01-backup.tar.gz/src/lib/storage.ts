// ─── Storage utilities for Employees and Company config ───
// Uses localStorage for persistence in this client-side app

export interface Employee {
  id: string
  name: string
  designation: string
  department: string
  joining_date: string
  basic: number
  house_rent: number
  conveyance: number
  medical: number
  food_mobile: number
  cash: number
  gross: number
  tax: number
  net: number
  bank_account: string
  bank_name: string
  nid: string
  mobile: string
  email: string
  status: 'active' | 'inactive'
  ref_code: string
}

export interface CompanyConfig {
  name: string
  address: string
  phone: string
  email: string
  proprietor_name: string
  proprietor_designation: string
  brand_color: string
  logo_path: string
}

const EMP_KEY = 'bh_employees'
const CO_KEY = 'bh_company'

const DEFAULT_COMPANY: CompanyConfig = {
  name: 'Beyond Headlines',
  address: 'Eureka Kanon Villa, House-84, Level-3, Road-10/1, Block-D, Niketon, Gulshan-1, Dhaka-1212, Bangladesh.',
  phone: '',
  email: '',
  proprietor_name: 'Saqib Ahmed',
  proprietor_designation: 'Proprietor',
  brand_color: '#FF2109',
  logo_path: '/Logo-main.png',
}

// ─── Employee CRUD ───

export function getAllEmployees(): Employee[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = localStorage.getItem(EMP_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

export function getEmployee(id: string): Employee | null {
  return getAllEmployees().find(e => e.id === id) || null
}

export function saveEmployee(emp: Employee): void {
  const list = getAllEmployees()
  const idx = list.findIndex(e => e.id === emp.id)
  if (idx >= 0) {
    list[idx] = emp
  } else {
    list.push(emp)
  }
  localStorage.setItem(EMP_KEY, JSON.stringify(list))
}

export function deleteEmployee(id: string): void {
  const list = getAllEmployees().filter(e => e.id !== id)
  localStorage.setItem(EMP_KEY, JSON.stringify(list))
}

// ─── Company Config ───

export function getCompany(): CompanyConfig {
  if (typeof window === 'undefined') return DEFAULT_COMPANY
  try {
    const raw = localStorage.getItem(CO_KEY)
    return raw ? { ...DEFAULT_COMPANY, ...JSON.parse(raw) } : DEFAULT_COMPANY
  } catch {
    return DEFAULT_COMPANY
  }
}

export function saveCompany(config: CompanyConfig): void {
  localStorage.setItem(CO_KEY, JSON.stringify(config))
}

// ─── Seed Default Data ───

export function seedDefaultData(): boolean {
  if (typeof window === 'undefined') return false

  const existing = localStorage.getItem(EMP_KEY)
  let needsSeed = false
  if (!existing) {
    needsSeed = true
  } else {
    try {
      const parsed = JSON.parse(existing)
      if (!Array.isArray(parsed)) needsSeed = true
    } catch {
      needsSeed = true
    }
  }

  if (!needsSeed) return false

  const defaultEmployees: Employee[] = [
    {
      id: 'EMP001',
      name: 'Syed Ashfaqul Haque',
      designation: 'Editor',
      department: 'Editorial',
      joining_date: '2025-10-01',
      basic: 150000,
      house_rent: 75000,
      conveyance: 30000,
      medical: 22500,
      food_mobile: 22500,
      cash: 143000,
      gross: 443000,
      tax: 43000,
      net: 400000,
      bank_account: 'Bank T/F',
      bank_name: '',
      nid: '',
      mobile: '',
      email: '',
      status: 'active',
      ref_code: 'TBH-46077',
    },
  ]
  localStorage.setItem(EMP_KEY, JSON.stringify(defaultEmployees))

  if (!localStorage.getItem(CO_KEY)) {
    localStorage.setItem(CO_KEY, JSON.stringify(DEFAULT_COMPANY))
  }

  return true
}
