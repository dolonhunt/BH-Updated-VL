import { NextRequest, NextResponse } from 'next/server'
import { execFile } from 'child_process'
import { writeFile, mkdir } from 'fs/promises'
import path from 'path'
import { randomUUID } from 'crypto'

export async function POST(request: NextRequest) {
  const htmlContent = await request.text()
  if (!htmlContent) {
    return NextResponse.json({ error: 'No HTML content' }, { status: 400 })
  }

  const tmpDir = path.join(process.cwd(), '.tmp')
  await mkdir(tmpDir, { recursive: true })

  const id = randomUUID()
  const htmlPath = path.join(tmpDir, `${id}.html`)
  const pdfPath = path.join(tmpDir, `${id}.pdf`)

  try {
    await writeFile(htmlPath, htmlContent, 'utf-8')

    await new Promise<void>((resolve, reject) => {
      execFile('pagedjs-cli', [htmlPath, '-o', pdfPath], { timeout: 30000 }, (err, stdout, stderr) => {
        if (err) {
          console.error('pagedjs-cli error:', stderr || err.message)
          reject(err)
        } else {
          resolve()
        }
      })
    })

    const { readFile, unlink } = await import('fs/promises')
    const pdfBuffer = await readFile(pdfPath)

    // Cleanup
    await unlink(htmlPath).catch(() => {})
    await unlink(pdfPath).catch(() => {})

    return new NextResponse(pdfBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': 'attachment; filename="document.pdf"',
      },
    })
  } catch (err) {
    console.error('PDF generation error:', err)
    // Cleanup on error
    const { unlink } = await import('fs/promises')
    await unlink(htmlPath).catch(() => {})
    await unlink(pdfPath).catch(() => {})
    return NextResponse.json({ error: 'PDF generation failed' }, { status: 500 })
  }
}
